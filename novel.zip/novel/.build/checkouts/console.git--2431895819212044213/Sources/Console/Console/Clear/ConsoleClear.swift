public enum ConsoleClear {
    case screen
    case line
}
