extension Filter {
    /**
        Describes the methods for comparing
        a value to a set of values.
    */
    public enum Scope {
        case `in`, notIn
    }
}
