public enum RelationError: Error {
    case noIdentifier
}
