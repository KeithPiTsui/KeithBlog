import XCTest
@testable import Cache

/**
    TODO: Finish when Fluent has a memory driver.
*/
class FluentCacheTests: XCTestCase {
    static let allTests = [
        ("testBasic", testBasic)
    ]

    var cache: FluentCache!

    override func setUp() {
        // cache = FluentCache()
    }

    func testBasic() throws {
        // TODO
    }
}
