import Console

public enum CommandError: Swift.Error {
    case general(String)
}
