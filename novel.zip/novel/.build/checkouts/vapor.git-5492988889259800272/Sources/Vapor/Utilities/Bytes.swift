import Core

public typealias Byte = Core.Byte
public typealias Bytes = Core.Bytes
