public protocol EmptyInitializable {
    init()
}

public protocol DropletInitializable {
    init(_: Droplet)
}
