public enum ProvidableError: Error {
    case overwritten(Any.Type)
}
