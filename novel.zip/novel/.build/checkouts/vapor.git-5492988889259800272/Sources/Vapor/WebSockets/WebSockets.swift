import WebSockets

public typealias WebSocket = WebSockets.WebSocket
@_exported import func Core.background
