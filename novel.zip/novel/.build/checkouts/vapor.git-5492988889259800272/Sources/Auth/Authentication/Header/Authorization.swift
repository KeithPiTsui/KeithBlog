import Turnstile

public struct Authorization {
    public let header: String

    public init(header: String) {
        self.header = header
    }
}
