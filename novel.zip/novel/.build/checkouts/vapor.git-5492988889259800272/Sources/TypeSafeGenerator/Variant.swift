enum Variant {
    case base, socket
}
