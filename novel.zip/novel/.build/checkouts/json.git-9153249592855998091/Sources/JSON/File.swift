import Node

public final class JSONContext: Context {
    public init() {}
}
