import XCTest
@testable import CLibreSSLTests

XCTMain([
     testCase(CLibreSSLTests.allTests),
])
