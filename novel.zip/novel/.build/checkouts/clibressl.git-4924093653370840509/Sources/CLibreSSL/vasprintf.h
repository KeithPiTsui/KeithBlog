#ifndef H_VASPRINTF
#define H_VASPRINTF

int
vasprintf(char **str, const char *fmt, va_list ap);

#endif
